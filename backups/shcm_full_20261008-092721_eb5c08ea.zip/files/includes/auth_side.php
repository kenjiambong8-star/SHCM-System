<div class="side">
  <div class="brand">SHCM System</div>
  <div>
    <h1>Student health clearance, tracked and verified.</h1>
    <p class="chk"><b>&#10003;</b> Monitor every health requirement and expiry date</p>
    <p class="chk"><b>&#10003;</b> See who is cleared at a glance</p>
    <p class="chk"><b>&#10003;</b> Encrypted access with a full audit trail</p>
  </div>
  <div style="font-size:13px;color:#BFD8CD">Student Health Clearance and Monitoring System</div>
</div>